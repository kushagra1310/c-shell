#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(void) {
    int n, pid;
    int i;
    uint64 start_time, end_time;
    
    printf("=== SCHEDULER PERFORMANCE TEST ===\n");
    start_time = uptime();
    
    // Create 10 children
    for (n = 0; n < 10; n++) {
        pid = fork();
        if (pid < 0) {
            printf("Fork failed at process %d\n", n);
            break;
        }
        
        if (pid == 0) {
            if (n < 5) {
                // First 5 are I/O-bound
                printf("I/O Process %d (PID: %d) starting\n", n, getpid());
                for(int j = 0; j < 5; j++) {
                    pause(40);
                    printf("I/O-%d ", getpid());
                }
            } else {
                // Next 5 are CPU-bound  
                printf("CPU Process %d (PID: %d) starting\n", n, getpid());
                for (volatile int j = 0; j < 1000000000; j++) {
                    if (j % 100000000 == 0) {
                        printf("P%d ", getpid());
                    }
                }
            }
            exit(0);
        }
    }
    
    // Parent waits for all children
    for (i = 0; i < n; i++) {
        wait(0);
    }
    
    end_time = uptime();
    printf("\n=== TEST RESULTS ===\n");
    printf("Total test time: %lu ticks\n", end_time - start_time);
    printf("Average time per process: %lu ticks\n", (end_time - start_time) / n);
    
    printf("\n=== DETAILED PROCESS STATISTICS ===\n");
    getpinfo(); // This will show wait times and run times
    
    exit(0);
}