#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Simple delay function using uptime() - works reliably in RISC-V xv6
void delay(int ticks) {
    int start = uptime();
    while (uptime() - start < ticks) {
        // Busy wait - this ensures we don't interfere with scheduler testing
    }
}

void simple_worker(char id) {
    int start = uptime();
    int count = 0;
    
    printf("Process %c starting at time %d\n", id, start);
    
    // Run for about 50 ticks
    while (uptime() - start < 50) {
        // Print our ID every so often to show when we're running
        if (count % 5000 == 0) {
            printf("%c", id);
        }
        count++;
        
        // Small amount of work
        volatile int dummy = 0;
        for (int i = 0; i < 100; i++) {
            dummy += i;
        }
    }
    
    printf("\nProcess %c finished (count: %d) at time %d\n", id, count, uptime());
}

int main() {
    printf("Simple scheduler test - watch the output pattern:\n");
    printf("FCFS should show: AAA...BBB...CCC...\n");
    printf("Round Robin should show: ABCABC...\n");
    printf("CFS should show: fair distribution\n\n");
    
    int start_time = uptime();
    printf("Test starting at time %d\n", start_time);
    
    // Create 3 processes with slight delays
    if (fork() == 0) {
        simple_worker('A');
        exit(0);
    }
    
    delay(2); // Use our delay function instead of sleep
    
    if (fork() == 0) {
        simple_worker('B'); 
        exit(0);
    }
    
    delay(2);
    
    if (fork() == 0) {
        simple_worker('C');
        exit(0);
    }
    
    // Wait for all children
    wait(0);
    wait(0);
    wait(0);
    
    printf("\n\nTest completed at time %d!\n", uptime());
    printf("Total test duration: %d ticks\n", uptime() - start_time);
    return 0;
}